The notebooks of "Lomdim Python" were lovingly created by (`Yam Mesicka <https://www.mesicka.com>`_).

- Editor: `Dafi Bar Ilan <https://www.dafibarilan.com/>`_
- Logo: `Eliel Dan Levy <https://www.elielart.com/>`_

Patches, Suggestions and More
```````````````````````

- Itamar Raviv
- Ido Elkabetz
